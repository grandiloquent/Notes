# Android Studio

## adb

```
C:\Users\psycho\AppData\Local\Android\Sdk\platform-tools\adb shell
cd /storage/19E7-1704/Books/Safari/EPUB && ls -R >/storage/19E7-1704/books.txt
C:\Users\psycho\AppData\Local\Android\Sdk\platform-tools\adb  pull /storage/19E7-1704/books.txt 
```

## 快捷键

|主菜单|菜单|快捷键|
|---|---|---|
|Analyze|Code Cleanup||
|Code|Collapse All|Ctrl+1|
|Code|Expand All|Ctrl+2|
|Code|Optimize Imports|Ctrl+Alt+O|
|Code|Generate|Alt+Insert|
|Code|Rearrange Code|F2|
|Code|Reformat Code|F1|

## 禁止 Debug C++

工具栏 - app - Run/Debug Configurations - Debugger - Debug type - Java