# PostgreSQL



## C#


```
private const string DefaultConnectionString = "Server=localhost;User ID=postgres;Password=Postgre;Database=postgres;Timeout=0;Command Timeout=0";
	
```

- http://www.npgsql.org/
- https://github.com/npgsql/npgsql

## 默认配置

```
Data Directory:C:\Program Files\PostgreSQL\11\data
Password:Postgre
Port:5432
Locale:[Default locale]
Installation Directory: C:\Program Files\PostgreSQL\11
Server Installation Directory: C:\Program Files\PostgreSQL\11
Data Directory: C:\Program Files\PostgreSQL\11\data
Database Port: 5432
Database Superuser: postgres
Operating System Account: NT AUTHORITY\NetworkService
Database Service: postgresql-x64-11
Command Line Tools Installation Directory: C:\Program Files\PostgreSQL\11
pgAdmin4 Installation Directory: C:\Program Files\PostgreSQL\11\pgAdmin 4
Stack Builder Installation Directory: C:\Program Files\PostgreSQL\11
```

- https://www.enterprisedb.com/downloads/postgres-postgresql-downloads