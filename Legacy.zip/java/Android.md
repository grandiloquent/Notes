# Java: Android

DiffUtil.calculateDiff site:android.googlesource.com

aria2c --https-proxy="https://127.0.0.1:56987" https://android.googlesource.com/platform/developers/samples/android/+archive/master.tar.gz
