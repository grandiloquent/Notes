# Java: Android 框架

## Room

 `app\build\intermediates\javac`

- http://reactivex.io/documentation/operators.html
- https://developer.android.com/training/data-storage/room/accessing-data



