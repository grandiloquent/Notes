# Effective Java

- [Effective Java (上)](https://github.com/grandiloquent/Notes/blob/master/java/Effective%20Java%20(%E4%B8%8A).md)
- [Effective Java (中)](https://github.com/grandiloquent/Notes/blob/master/java/Effective%20Java%20(%E4%B8%AD).md)
- [Effective Java (下)](https://github.com/grandiloquent/Notes/blob/master/java/Effective%20Java%20(%E4%B8%8B).md)